package com.buildingmanagement.buildingmanagementbackend.integration;

public class TestConfig {
}
