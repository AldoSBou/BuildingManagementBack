package com.buildingmanagement.buildingmanagementbackend.integration.controller;

public class AuthControllerTest {
}
