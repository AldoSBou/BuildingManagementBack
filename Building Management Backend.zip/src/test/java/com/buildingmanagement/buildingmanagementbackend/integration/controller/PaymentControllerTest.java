package com.buildingmanagement.buildingmanagementbackend.integration.controller;

public class PaymentControllerTest {
}
