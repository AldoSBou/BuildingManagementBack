package com.buildingmanagement.buildingmanagementbackend.unit.repository;

public class UserRepositoryTest {
}
