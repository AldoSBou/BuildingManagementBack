package com.buildingmanagement.buildingmanagementbackend.unit.service;

public class FeeServiceTest {
}
