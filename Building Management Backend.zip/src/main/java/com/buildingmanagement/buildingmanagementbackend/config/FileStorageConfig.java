package com.buildingmanagement.buildingmanagementbackend.config;

public class FileStorageConfig {
}
