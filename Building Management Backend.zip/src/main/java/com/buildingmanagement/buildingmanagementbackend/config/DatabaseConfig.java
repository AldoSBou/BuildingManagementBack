package com.buildingmanagement.buildingmanagementbackend.config;

public class DatabaseConfig {
}
