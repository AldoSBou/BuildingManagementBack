package com.buildingmanagement.buildingmanagementbackend.shared.audit;

public class AuditingConfig {
}
