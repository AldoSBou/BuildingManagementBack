package com.buildingmanagement.buildingmanagementbackend.shared.dto;

public class ErrorResponse {
}
