package com.buildingmanagement.buildingmanagementbackend.common.constans;

public class SecurityConstants {
}
