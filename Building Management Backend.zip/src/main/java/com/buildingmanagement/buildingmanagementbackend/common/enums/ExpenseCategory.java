package com.buildingmanagement.buildingmanagementbackend.common.enums;

public enum ExpenseCategory {
    CLEANING,
    SECURITY
}
