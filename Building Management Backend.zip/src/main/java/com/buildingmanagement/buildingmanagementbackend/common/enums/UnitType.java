package com.buildingmanagement.buildingmanagementbackend.common.enums;

public enum UnitType {
    APARTMENT,
    PARKING,
    STORAGE,
    COMMERCIAL
}
