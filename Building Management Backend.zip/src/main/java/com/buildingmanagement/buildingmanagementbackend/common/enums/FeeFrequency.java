package com.buildingmanagement.buildingmanagementbackend.common.enums;

public enum FeeFrequency {
    MONTHLY,
    QUARTERLY,
    ANNUAL,
    ONE_TIME
}