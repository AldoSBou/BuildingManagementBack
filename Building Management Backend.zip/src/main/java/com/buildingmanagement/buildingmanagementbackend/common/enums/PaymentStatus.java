package com.buildingmanagement.buildingmanagementbackend.common.enums;

public enum PaymentStatus {
    PENDING,
    PAID,
    OVERDUE,
    PARTIAL,
    CANCELLED
}
