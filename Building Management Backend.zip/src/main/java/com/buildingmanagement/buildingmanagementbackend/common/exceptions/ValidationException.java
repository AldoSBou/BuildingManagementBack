package com.buildingmanagement.buildingmanagementbackend.common.exceptions;

public class ValidationException {
}
