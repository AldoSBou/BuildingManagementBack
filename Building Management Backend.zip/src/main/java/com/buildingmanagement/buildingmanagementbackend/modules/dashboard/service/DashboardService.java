package com.buildingmanagement.buildingmanagementbackend.modules.dashboard.service;

public interface DashboardService {
}
