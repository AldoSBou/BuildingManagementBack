package com.buildingmanagement.buildingmanagementbackend.modules.payment.service;

public interface PaymentService {
}
