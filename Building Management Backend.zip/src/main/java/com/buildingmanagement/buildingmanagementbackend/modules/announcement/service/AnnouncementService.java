package com.buildingmanagement.buildingmanagementbackend.modules.announcement.service;

public interface AnnouncementService {
}
