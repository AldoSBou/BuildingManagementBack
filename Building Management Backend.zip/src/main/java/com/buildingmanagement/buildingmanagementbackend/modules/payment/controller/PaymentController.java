package com.buildingmanagement.buildingmanagementbackend.modules.payment.controller;

public class PaymentController {
}
