package com.buildingmanagement.buildingmanagementbackend.modules.user.dto;

public class UserCreateRequest {
}
