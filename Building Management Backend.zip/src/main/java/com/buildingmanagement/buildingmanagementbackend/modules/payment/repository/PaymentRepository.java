package com.buildingmanagement.buildingmanagementbackend.modules.payment.repository;

public class PaymentRepository {
}
