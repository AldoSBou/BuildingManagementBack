package com.buildingmanagement.buildingmanagementbackend.modules.announcement.mapper;

public class AnnouncementMapper {
}
