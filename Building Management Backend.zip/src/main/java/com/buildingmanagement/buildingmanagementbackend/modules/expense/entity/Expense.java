package com.buildingmanagement.buildingmanagementbackend.modules.expense.entity;

public class Expense {
}
