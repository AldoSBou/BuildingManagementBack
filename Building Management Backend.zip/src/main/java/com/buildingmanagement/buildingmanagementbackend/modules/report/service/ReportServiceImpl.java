package com.buildingmanagement.buildingmanagementbackend.modules.report.service;

public class ReportServiceImpl {
}
