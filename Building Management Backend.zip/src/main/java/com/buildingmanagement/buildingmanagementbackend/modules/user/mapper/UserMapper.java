package com.buildingmanagement.buildingmanagementbackend.modules.user.mapper;

public class UserMapper {
}
