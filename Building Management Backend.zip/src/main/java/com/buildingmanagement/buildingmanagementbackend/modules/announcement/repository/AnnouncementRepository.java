package com.buildingmanagement.buildingmanagementbackend.modules.announcement.repository;

public interface AnnouncementRepository {
}
