package com.buildingmanagement.buildingmanagementbackend.modules.fee.service;

public interface FeeService {
}
