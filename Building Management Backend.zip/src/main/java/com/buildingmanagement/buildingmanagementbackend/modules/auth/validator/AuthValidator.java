package com.buildingmanagement.buildingmanagementbackend.modules.auth.validator;

public class AuthValidator {
}
