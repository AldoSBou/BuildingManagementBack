package com.buildingmanagement.buildingmanagementbackend.modules.announcement.entity;

public class Announcement {
}
