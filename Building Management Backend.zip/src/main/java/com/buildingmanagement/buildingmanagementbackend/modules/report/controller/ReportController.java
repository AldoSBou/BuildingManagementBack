package com.buildingmanagement.buildingmanagementbackend.modules.report.controller;

public class ReportController {
}
