package com.buildingmanagement.buildingmanagementbackend.modules.expense.service;

public interface ExpenseService {
}
