package com.buildingmanagement.buildingmanagementbackend.modules.fee.controller;

public class FeeController {
}
