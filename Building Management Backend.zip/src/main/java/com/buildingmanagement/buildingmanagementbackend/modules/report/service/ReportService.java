package com.buildingmanagement.buildingmanagementbackend.modules.report.service;

public interface ReportService {
}
