package com.buildingmanagement.buildingmanagementbackend.modules.dashboard.service;

public class DashboardServiceImpl {
}
