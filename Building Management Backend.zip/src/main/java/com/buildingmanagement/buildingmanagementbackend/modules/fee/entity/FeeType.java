package com.buildingmanagement.buildingmanagementbackend.modules.fee.entity;

public class FeeType {
}
