package com.buildingmanagement.buildingmanagementbackend.modules.payment.entity;

public class Payment {
}
