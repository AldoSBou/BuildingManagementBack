package com.buildingmanagement.buildingmanagementbackend.modules.payment.service;

public class PaymentServiceImpl {
}
