package com.buildingmanagement.buildingmanagementbackend.modules.expense.mapper;

public class ExpenseMapper {
}
