package com.buildingmanagement.buildingmanagementbackend.modules.user.controller;

public class UserController {
}
