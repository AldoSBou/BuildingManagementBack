package com.buildingmanagement.buildingmanagementbackend.modules.announcement.dto;

public class AnnouncementResponse {
}
