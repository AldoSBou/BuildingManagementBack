package com.buildingmanagement.buildingmanagementbackend.modules.report.generator;

public class ExcelReportGenerator {
}
