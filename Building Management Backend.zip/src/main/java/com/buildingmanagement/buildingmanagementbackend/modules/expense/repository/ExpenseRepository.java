package com.buildingmanagement.buildingmanagementbackend.modules.expense.repository;

public class ExpenseRepository {
}
