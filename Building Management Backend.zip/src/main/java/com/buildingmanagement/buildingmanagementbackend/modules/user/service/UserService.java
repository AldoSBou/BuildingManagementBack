package com.buildingmanagement.buildingmanagementbackend.modules.user.service;

public interface UserService {
}
