package com.buildingmanagement.buildingmanagementbackend.modules.expense.dto;

public class ExpenseResponse {
}
