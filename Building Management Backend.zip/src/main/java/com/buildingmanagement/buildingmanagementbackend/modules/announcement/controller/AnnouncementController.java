package com.buildingmanagement.buildingmanagementbackend.modules.announcement.controller;

public class AnnouncementController {
}
