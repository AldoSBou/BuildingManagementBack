package com.buildingmanagement.buildingmanagementbackend.modules.expense.service;

public class ExpenseServiceImpl {
}
