package com.buildingmanagement.buildingmanagementbackend.modules.report.dto;

public class UnitAccountStatementResponse {
}
