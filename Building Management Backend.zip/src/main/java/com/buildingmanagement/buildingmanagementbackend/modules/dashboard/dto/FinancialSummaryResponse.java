package com.buildingmanagement.buildingmanagementbackend.modules.dashboard.dto;

public class FinancialSummaryResponse {
}
