package com.buildingmanagement.buildingmanagementbackend.modules.payment.dto;

public class PaymentCreateRequest {
}
