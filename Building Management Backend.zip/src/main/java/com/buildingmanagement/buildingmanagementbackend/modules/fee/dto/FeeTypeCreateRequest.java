package com.buildingmanagement.buildingmanagementbackend.modules.fee.dto;

public class FeeTypeCreateRequest {
}
