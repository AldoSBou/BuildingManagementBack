package com.buildingmanagement.buildingmanagementbackend.modules.expense.controller;

public class ExpenseController {
}
