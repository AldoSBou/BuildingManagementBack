package com.buildingmanagement.buildingmanagementbackend.modules.fee.repository;

public class FeeTypeRepository {
}
