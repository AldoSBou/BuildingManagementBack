package com.buildingmanagement.buildingmanagementbackend.modules.dashboard.controller;

public class DashboardController {
}
