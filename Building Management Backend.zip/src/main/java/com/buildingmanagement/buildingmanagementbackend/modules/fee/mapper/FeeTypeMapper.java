package com.buildingmanagement.buildingmanagementbackend.modules.fee.mapper;

public class FeeTypeMapper {
}
