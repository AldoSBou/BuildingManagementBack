package com.buildingmanagement.buildingmanagementbackend.modules.payment.mapper;

public class PaymentMapper {
}
